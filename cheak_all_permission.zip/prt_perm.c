#include<stdio.h>
#include<sys/stat.h>
#include<unistd.h>
#include<stdlib.h>

void print_permission(char* fname, struct stat* buffer)
{
	if((lstat(fname,buffer)) == -1)
	{
		perror("lstat");
		exit(1);
	}
	else
	{
		printf("The all permission of %s is : %o\n",fname,buffer->st_mode);
		printf("The security permission of %s is %o\n",fname,buffer->st_mode & ~S_IFMT);
	}
}
