#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void print_permission(char*, struct stat*);
void check_permission(int, int, char*);

void main(int argc, char* argv[])
{
	struct stat stat_buffer;
	int perm, i;

	if(argc != 2)
	{
		if(argc > 2)
			printf("Too many arguments...\n");
		else
			printf("No arguments found...\n");
		exit(1);
	}

	mode_t perm_flag[] = {  S_IRUSR, S_IWUSR, S_IXUSR,
				S_IRGRP, S_IWGRP, S_IXGRP,
				S_IROTH, S_IWGRP, S_IXGRP,
				S_ISUID, S_ISGID, S_ISVTX
			     };
	char* msg[] = {"User-readable", "User-writable", "User-Executable",
			"Group-readable", "Group-writable", "Group-executable",
			"Others-readable", "Others-writable", "Others-executable",
			"SUID bit set", "SGIP bit set", "Sticky bit set"
		      };

	print_permission(argv[1], &stat_buffer);

	perm = stat_buffer.st_mode & ~S_IFMT;

	for(i=0;i<12;i++)
	{
		check_permission(perm,perm_flag[i],msg[i]);
	}
	exit(0);
}
