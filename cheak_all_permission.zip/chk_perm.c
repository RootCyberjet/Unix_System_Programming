#include<stdio.h>

void check_permission(int perm, int flag, char* msg)
{
	if(perm & flag)
	{
		printf("%s\n", msg);
	}
	else
	{
		printf("Not %s\n", msg);
	}
}
